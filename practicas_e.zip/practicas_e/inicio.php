<?php
  /* Tipos de dato Boolean: almacenas valores de verdadero y falso / Intenger: Entero
Float: Numeros con decimales utilizan el punto de simal como un separador
String: Cadena de caracteres Tipos de datos compuestos / Array: se utiliza para almacenar varios valores Object: almacena objetos dentro de php
Tipos de datos especiales
Resource: hace referencia a recursos (archivos abiertos o conexiones establecidas) / Null: un valor nulo
*/
// primero se declara con un signo $ -> nombre o identificador (mayusculas y minusculas) // $8variable = erronea 
// $_8variable = correcto // $variable8 = correcto // $8_variable = erronea
 $numero = 7  ; 
$Nombre = " eder uriel padilla dominguez";
  $Mivariable = " valor";
echo $numero; echo $Nombre; echo $Mivariable;
?>
