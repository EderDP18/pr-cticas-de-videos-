<?php /* foreach(expresion as $variable) {acciones que se tendra dentro del bucle}*/
$arreglo = ["abcdefghijklmnopqrst",30,'e',56.5,true,false,12]; echo "<pre>\n";
var_dump($arreglo); echo "</pre>\n";
foreach($arreglo as $Recorrido){ echo "<p>$Recorrido</p>\n";} echo "Termina el ciclo <br>"; ?>