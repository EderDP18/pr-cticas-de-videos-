<?php /* for(experecion1; expresion2; expresion3){sentencio o instrucciones}
*/
/*for(iniciar el ciclo; condicion; incremento o decremento){ instrucciones que se ejecutaran si se cumple la condicion}
for(iniciar el ciclo; condicion; incremento o decremento):
 las instrucciones que se realizaran si se cumple el ciclo
endfor; *//*echo "La Lista de numeros pares es: ";
for($i= 2; $i <= 26; $i = $i + 2){ echo "</br>"; echo $i; echo "</br>";}
*//* for($x = 1; $x <= 20; $x = $x + 1) {echo $x." Ejecutando el ciclo </br>";}
echo "Termina el ciclo";*/

for ($j = 1; $j <= 5; $j++): echo $j; echo"</br>"; endfor;
echo "termina el ciclo que se repite" .$j; ?>