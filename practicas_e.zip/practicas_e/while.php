<?php
//trabajaremos con el ciclo while y de .. while
/* while(Expresion o validacion){
    acciones se cumpla la expresion
}do{   Sentencia o accion
}while(Expresion o validacion);
*/
/* 
$variable = 0; while($variable < 50){
    $variable ++; // se incrementa $variable uno en uno echo "El valor de la variable es= ".$variable."</br></br>";
}echo "El ciclo while acaba en: ".$variable;
*/ $variable = 20;
do{echo $variable." </br>"; $variable ++; } while($variable <= 30); ?>
