<?php $Entero = 54;
   $Flotante = 21.4; $Verdadero = true;
 $Falso = false;  $String = "El numero que se encuentra almacenado en la variable Entero es: ";
 /* print "Esto es una sola cadena<br>";echo "Esto es una sola cadena","Esta es una segunda cadena";*/
/*
     echo $String,$Entero,"<br>";print $Flotante."<br>";
print $Falso;*//*echo var_dump($Flotante);
echo "<br>";

echo var_dump($Entero); echo "<br>";echo var_dump($Verdadero);
echo "<br>";

echo var_dump($Falso);              echo "<br>";
echo var_dump($String);
*/
/*
$Lenguajes = array("JavaScript","ASP","Java","C++","Python","PHP",35);
 echo var_dump($Lenguajes);
*/$saludo = null;$saludo = "programando con php";echo var_dump($saludo);
/*Pseudo-Types. mixed(Mezclado), number(Numero), Callback(retorno invocable), array,object, void
*/ ?>